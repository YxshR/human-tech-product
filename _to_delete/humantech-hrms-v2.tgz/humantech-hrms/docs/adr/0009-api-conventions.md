# ADR-0009: API conventions

- Kebab-case plural resources: `/leave-requests/{id}/approve`, `/payroll-runs/{id}/finalize` (American spelling in code and URLs).
- Tenant comes from the verified session, never from a path/body/header the client controls.
- Success: `{ "data": ... }`; lists add `{ "page": { "nextCursor", "limit" } }` (cursor pagination only).
- Errors: `{ "error": { "code", "message", "requestId", "fields?" } }` with stable codes. DB-raised SQLSTATEs map to codes in one table (`SQLSTATE_TO_ERROR`) covered by a parity test.
- Out-of-tenant or out-of-scope records return 404, missing permission 403 (no existence oracle).
- Mutations that create or move money or documents accept `Idempotency-Key`. Updates use optimistic `version`.
- Request bodies are `.strict()` Zod schemas: unknown keys (e.g. `tenantId`, `payrollEligible`) are rejected, preventing mass assignment.
