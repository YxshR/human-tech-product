import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = { title: { default: 'humanTech HRMS', template: '%s · humanTech' }, robots: { index: false, follow: false } };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en-IN">
      <body>{children}</body>
    </html>
  );
}
